package com.example.moviemagic;

//imports

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class Ratings extends AppCompatActivity {

    //declarations

    MyDatabase myDb;
    Context ctx = this;

    public static ArrayList<String> moviesExistingInDb = new ArrayList<String>();
    public static ArrayList<RadioButton> radioBtnArr = new ArrayList<RadioButton>();
    public static ArrayList<TextView> textViewTitleArr = new ArrayList<TextView>();
    public static ArrayList<String> imgStringArr = new ArrayList<String>();

    RadioButton radioButton;
    LinearLayout linearLayout;

    private int count;
    private static final String TAG = "SearchByTitle";
    public static int position;
    public String searchUrl;
    public String movieTitle = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ratings);

        myDb = new MyDatabase(ctx);
        linearLayout = findViewById(R.id.linear_ratings);

        myDb.displayMoviesInDb();

        //for loop to create RadioButtons to represent the movie titles in the current database
        for (int i = 0; i < moviesExistingInDb.size(); i++) {
            int tempI = i;
            radioButton = new RadioButton(ctx);
            radioButton.setClickable(true);
            radioButton.setTextColor(Color.WHITE);
            radioButton.setText(moviesExistingInDb.get(i));
            radioBtnArr.add(radioButton);
            linearLayout.addView(radioButton);

            //creating an onClickListener for each of the RadioButtons
            radioButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    for (int i2 = 0; i2 < radioBtnArr.size(); i2++) {
                        if (i2 != tempI) {
                            radioBtnArr.get(i2).setChecked(false);
                        } else {
                            position = i2;
                        }
                    }
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        moviesExistingInDb.clear();
        radioBtnArr.clear();
    }

    //findMovieInIMDB Button onClick
    public void findMovieInIMDBBtn(View view) {

        //incrementing the number of times by which the ratingsMainBtn has been pressed
        count += 1;
        Button ratingsMainBtn = findViewById(R.id.findMovieInIMDB_btn);
        ratingsMainBtn.setTextColor(Color.WHITE);

        //checking whether ratingsMainBtn has been pressed 1 time
        if (count == 1) {
            linearLayout.removeAllViews();

            //url to search the IMDB database
            searchUrl = "https://imdb-api.com/en/API/SearchTitle/k_z4ngctwh/" +
                    radioBtnArr.get(position).getText().toString();

            //creating a background thread
            Thread searchByTitleThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    for (int i = 1; i <= 5; i++) {
                        Log.d(TAG, "Thread iteration number : " + i);
                        try {
                            //Thread.sleep(1000);

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                    try {
                        InputStream inputStream;

                        //connecting to the Internet
                        URL url = new URL(searchUrl);
                        HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                        httpURLConnection.setRequestMethod("GET");
                        httpURLConnection.connect();

                        inputStream = httpURLConnection.getInputStream();

                        //creating a BufferedReader to read from the array retrieved from the url
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

                        movieTitle = bufferedReader.readLine();

                        //creating a JSONObject and JSONArray
                        JSONObject jsonObject = new JSONObject(movieTitle);
                        JSONArray jsonArray = jsonObject.getJSONArray("results");

                        movieTitle = "";
                        TextView textViewTitle;

                        //for loop creating the TextViews relating to the retrieved IMDB movie titles
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject title = jsonArray.getJSONObject(i);
                            //movieTitle = movieTitle + "\n" + title.getString("title");
                            textViewTitle = new TextView(ctx);
                            textViewTitle.setText(title.getString("title"));
                            textViewTitleArr.add(textViewTitle);
                            imgStringArr.add(title.getString("image"));
                            textViewTitle.setClickable(true);
                            textViewTitle.setTextColor(Color.WHITE);

                            TextView finalTextViewTitle = textViewTitle;
                            int finalI = i;
                            //adding an onClickListener to each of the movie title TextViews from the IMDB database
                            textViewTitle.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    finalTextViewTitle.setTextColor(Color.parseColor("#00B4E1"));

//                                    ImageView imageView = null;
//                                    Bitmap bitmap = null;
//
//                                    try {
//                                        InputStream inputStream1 = new java.net.URL(imgStringArr.get(finalI)).openStream();
//                                        bitmap = BitmapFactory.decodeStream(inputStream1);
//                                    }
//                                    catch (Exception e) {
//                                        e.printStackTrace();
//                                    }
//
//                                    Bitmap finalBitmap = bitmap;
//                                    imageView.setImageBitmap(finalBitmap);
//
//                                    System.out.println("------------------------------------------------------------" +
//                                            "------------" + imgStringArr.get(finalI));
//
//                                    linearLayout.removeAllViews();
//                                    linearLayout.addView(imageView);
                                }
                            });
                        }

                        System.out.println("----------------------------" + movieTitle);

                        bufferedReader.close();
                        inputStream.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
            searchByTitleThread.start();

            //setting ratingMainBtn text to "Show Results"
            ratingsMainBtn.setText("Show Results");
        }

        //checking whether ratingsMainBtn has been pressed 2 times
        else if (count == 2) {

            //adding the titles of the movies from the IMDB database to the LinearLayout
            for (int i = 0; i < textViewTitleArr.size(); i++) {
                linearLayout.addView(textViewTitleArr.get(i));
            }
            //setting ratingMainBtn text to "Back to Home"
            ratingsMainBtn.setText("Back to Home");
        }

        //checking whether ratingsMainBtn has been pressed 3 times
        else if (count == 3) {

            //clearing the ArrayLists and returning to the home page
            textViewTitleArr.clear();
            moviesExistingInDb.clear();
            radioBtnArr.clear();
            startActivity(new Intent(Ratings.this, MainActivity.class));
        }
    }
}