package com.example.moviemagic;

//imports

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import static com.example.moviemagic.EditMovie.starsArr;

public class Search extends AppCompatActivity {

    //declarations

    MyDatabase myDb;
    Context ctx = this;

    public static String lookupEntered;
    public static String previousLookup;

    public static ArrayList<String> searchMovieTitles = new ArrayList<String>();
    public static ArrayList<Integer> searchYears = new ArrayList<Integer>();
    public static ArrayList<String> searchDirectors = new ArrayList<String>();
    public static ArrayList<String> searchActors = new ArrayList<String>();
    public static ArrayList<Integer> searchRatings = new ArrayList<Integer>();
    public static ArrayList<String> searchReviews = new ArrayList<String>();
    public static ArrayList<String> searchFavourites = new ArrayList<String>();

    public static EditText lookupString;
    LinearLayout linearLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        myDb = new MyDatabase(ctx);
        linearLayout = findViewById(R.id.linear_search);

        lookupString = findViewById(R.id.lookup_edit_text);
        previousLookup = "";
    }

    //lookupBtn Button onAction
    public void lookupBtn(View view) {

        lookupEntered = lookupString.getText().toString();

        //checking if any lookup String has been entered
        if (lookupEntered.equals("")) {
            Toast.makeText(ctx, "You need to enter a string to lookup!", Toast.LENGTH_SHORT).show();
        } else {
            //checking if the lookup button has been pressed again, without a change made to the lookup EditText
            if (!lookupEntered.equals(previousLookup)) {

                //removing any existing views from the LinearLayout
                linearLayout.removeAllViews();
                previousLookup = lookupEntered;

                //call to search method of MyDatabase class
                myDb.search();

                //for loop iterating through searchMovieTitles
                for (int i = 0; i < searchMovieTitles.size(); i++) {

                    ImageView star;

                    //LayoutParams for the TextViews
                    TableLayout.LayoutParams textViewParams = new TableLayout.LayoutParams();
                    textViewParams.setMargins(20, 0, 20, 0);

                    TableLayout.LayoutParams basicParams = new TableLayout.LayoutParams();
                    basicParams.setMargins(20, 10, 20, 100);

                    TableLayout.LayoutParams bottomParams = new TableLayout.LayoutParams();
                    bottomParams.setMargins(20, 10, 20, 300);

                    //creating TextViews
                    TextView textViewMovieTitle = new TextView(ctx);
                    TextView textViewYear = new TextView(ctx);
                    TextView textViewDirector = new TextView(ctx);
                    TextView textViewActors = new TextView(ctx);
                    TextView textViewReview = new TextView(ctx);
                    TextView textViewFavourite = new TextView(ctx);

                    //setting the LayoutParameters for the TextViews
                    textViewMovieTitle.setLayoutParams(basicParams);
                    textViewYear.setLayoutParams(basicParams);
                    textViewDirector.setLayoutParams(basicParams);
                    textViewActors.setLayoutParams(basicParams);
                    textViewReview.setLayoutParams(basicParams);
                    textViewFavourite.setLayoutParams(bottomParams);

                    //setting the attributes and text of the TextViews
                    TextView textView1 = new TextView(ctx);
                    textView1.setText("___________\n\nMovie Title");
                    textView1.setTextSize(20);
                    textView1.setLayoutParams(textViewParams);
                    textView1.setTextColor(Color.WHITE);
                    textViewMovieTitle.setText(searchMovieTitles.get(i));
                    textViewMovieTitle.setTextColor(Color.WHITE);

                    TextView textView2 = new TextView(ctx);
                    textView2.setText("Year");
                    textView2.setTextSize(20);
                    textView2.setLayoutParams(textViewParams);
                    textView2.setTextColor(Color.WHITE);
                    textViewYear.setText(searchYears.get(i) + "");
                    textViewYear.setTextColor(Color.WHITE);

                    TextView textView3 = new TextView(ctx);
                    textView3.setText("Director");
                    textView3.setTextSize(20);
                    textView3.setLayoutParams(textViewParams);
                    textView3.setTextColor(Color.WHITE);
                    textViewDirector.setText(searchDirectors.get(i));
                    textViewDirector.setTextColor(Color.WHITE);

                    TextView textView4 = new TextView(ctx);
                    textView4.setText("Actors/Actresses");
                    textView4.setTextSize(20);
                    textView4.setLayoutParams(textViewParams);
                    textView4.setTextColor(Color.WHITE);
                    textViewActors.setText(searchActors.get(i));
                    textViewActors.setTextColor(Color.WHITE);

                    TextView textView5 = new TextView(ctx);
                    textView5.setText("Rating");
                    textView5.setTextSize(20);
                    textView5.setLayoutParams(textViewParams);
                    textView5.setTextColor(Color.WHITE);

                    TextView textView6 = new TextView(ctx);
                    textView6.setText("Review");
                    textView6.setTextSize(20);
                    textView6.setLayoutParams(textViewParams);
                    textView6.setTextColor(Color.WHITE);
                    textViewReview.setText(searchReviews.get(i));
                    textViewReview.setTextColor(Color.WHITE);

                    LinearLayout innerLinear = new LinearLayout(ctx);
                    innerLinear.setOrientation(LinearLayout.HORIZONTAL);
                    innerLinear.setLayoutParams(basicParams);

                    //for loop to create and display the yellow stars
                    for (int i2 = 0; i2 < searchRatings.get(i); i2++) {
                        star = new ImageView(ctx);
                        star.setImageResource(R.drawable.ic_baseline_star_rate_24);
                        star.setColorFilter(Color.parseColor("#ffd000"));
                        star.setClickable(true);
                        starsArr.add(star);
                        innerLinear.addView(star);
                    }

                    //for loop to create and display the white stars
                    for (int i2 = searchRatings.get(i); i2 < 10; i2++) {
                        star = new ImageView(ctx);
                        star.setImageResource(R.drawable.ic_baseline_star_rate_24);
                        star.setColorFilter(Color.parseColor("#ffffff"));
                        star.setClickable(true);
                        starsArr.add(star);
                        innerLinear.addView(star);
                    }

                    TextView textView7 = new TextView(ctx);
                    textView7.setText("Status");
                    textView7.setTextSize(20);
                    textView7.setLayoutParams(textViewParams);
                    textView7.setTextColor(Color.WHITE);
                    textViewFavourite.setText(searchFavourites.get(i));
                    textViewFavourite.setTextColor(Color.WHITE);

                    //adding the TextViews to the LinearLayout
                    linearLayout.addView(textView1);
                    linearLayout.addView(textViewMovieTitle);

                    linearLayout.addView(textView2);
                    linearLayout.addView(textViewYear);

                    linearLayout.addView(textView3);
                    linearLayout.addView(textViewDirector);

                    linearLayout.addView(textView4);
                    linearLayout.addView(textViewActors);

                    linearLayout.addView(textView5);
                    linearLayout.addView(innerLinear);

                    linearLayout.addView(textView6);
                    linearLayout.addView(textViewReview);

                    linearLayout.addView(textView7);
                    linearLayout.addView(textViewFavourite);
                }

                //clearing the ArrayLists
                searchMovieTitles.clear();
                searchYears.clear();
                searchDirectors.clear();
                searchActors.clear();
                searchRatings.clear();
                searchReviews.clear();
                searchFavourites.clear();
            }
        }
    }
}