package com.example.moviemagic;

//imports

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class EditMovies extends AppCompatActivity {

    //declarations

    MyDatabase myDb;
    Context ctx = this;

    public static Button btn;

    public static ArrayList<String> editMovieTitles = new ArrayList<String>();
    public static ArrayList<Button> editMovieTitleButtons = new ArrayList<Button>();

    public static int position = 0;
    public static String movieToBeEdited = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_movies);

        myDb = new MyDatabase(ctx);
        myDb.editMovies();

        //Toast.makeText(ctx, editMovieTitles.toString(), Toast.LENGTH_SHORT).show();
        LinearLayout linearLayout = findViewById(R.id.linear_edit_movies);

        //for loop to create movie titles buttons of all the movies in the existing database
        for (int i = 0; i < editMovieTitles.size(); i++) {
            btn = new Button(ctx);
            btn.setText(editMovieTitles.get(i));
            btn.setTextColor(Color.WHITE);
            btn.setBackgroundColor(Color.TRANSPARENT);
            editMovieTitleButtons.add(btn);
            linearLayout.addView(btn);

            int finalI = i;
            //adding a listener to each of the movie title buttons
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    position = finalI;
                    movieToBeEdited = editMovieTitles.get(position);
                    btnOnClick();
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        editMovieTitles.clear();
        editMovieTitleButtons.clear();
    }

    //btnOnClick Button onClick
    public void btnOnClick() {
        startActivity(new Intent(EditMovies.this, EditMovie.class));
    }
}