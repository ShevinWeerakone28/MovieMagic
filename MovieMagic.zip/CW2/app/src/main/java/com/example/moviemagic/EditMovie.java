package com.example.moviemagic;

//imports

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class EditMovie extends AppCompatActivity {

    //declarations

    MyDatabase myDb;
    Context ctx = this;

    public static String movie_title = "";
    public static int year = 0;
    public static String director = "";
    public static String actors = "";
    public static int rating = 0;
    public static String review = "";
    public static String favourite = "";
    public static ImageView star;
    private static int iterations;
    private String originalTitle = "";

    EditText editMovieTitle;
    EditText editYear;
    EditText editDirector;
    EditText editActors;
    EditText editReview;
    EditText editFavourite;

    public static ArrayList<ImageView> starsArr = new ArrayList<ImageView>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_movie);

        myDb = new MyDatabase(ctx);
        LinearLayout linearLayout = findViewById(R.id.linear_edit_movie);

        editMovieTitle = new EditText(ctx);
        editYear = new EditText(ctx);
        editDirector = new EditText(ctx);
        editActors = new EditText(ctx);
        editReview = new EditText(ctx);
        editFavourite = new EditText(ctx);

        //setting the InputTypes for the EditTexts
        editMovieTitle.setInputType(InputType.TYPE_CLASS_TEXT);
        editYear.setInputType(InputType.TYPE_CLASS_NUMBER);
        editDirector.setInputType(InputType.TYPE_TEXT_VARIATION_PERSON_NAME);
        editActors.setInputType(InputType.TYPE_TEXT_VARIATION_PERSON_NAME);
        editReview.setInputType(InputType.TYPE_TEXT_FLAG_MULTI_LINE);

        //setting the LayoutParams for the TextViews and EditTexts
        TableLayout.LayoutParams textViewParams = new TableLayout.LayoutParams();
        textViewParams.setMargins(20, 0, 20, 0);

        TableLayout.LayoutParams basicParams = new TableLayout.LayoutParams();
        basicParams.setMargins(10, 10, 20, 100);

        //setting the layouts for the EditTexts
        editMovieTitle.setLayoutParams(basicParams);
        editYear.setLayoutParams(basicParams);
        editDirector.setLayoutParams(basicParams);
        editActors.setLayoutParams(basicParams);
        editReview.setLayoutParams(basicParams);
        editFavourite.setLayoutParams(basicParams);

        myDb.getEditMovie();

        //setting the attributes and text of the TextViews and EditTexts
        TextView textView1 = new TextView(ctx);
        textView1.setText("Movie Title");
        textView1.setLayoutParams(textViewParams);
        textView1.setTextColor(Color.WHITE);
        editMovieTitle.setText(movie_title);
        editMovieTitle.setTextColor(Color.WHITE);
        originalTitle = movie_title;

        TextView textView2 = new TextView(ctx);
        textView2.setText("Year");
        textView2.setLayoutParams(textViewParams);
        textView2.setTextColor(Color.WHITE);
        editYear.setText(year + "");
        editYear.setTextColor(Color.WHITE);

        TextView textView3 = new TextView(ctx);
        textView3.setText("Director");
        textView3.setLayoutParams(textViewParams);
        textView3.setTextColor(Color.WHITE);
        editDirector.setText(director);
        editDirector.setTextColor(Color.WHITE);

        TextView textView4 = new TextView(ctx);
        textView4.setText("Actors/Actresses");
        textView4.setLayoutParams(textViewParams);
        textView4.setTextColor(Color.WHITE);
        editActors.setText(actors);
        editActors.setTextColor(Color.WHITE);

        TextView textView5 = new TextView(ctx);
        textView5.setText("Rating");
        textView5.setLayoutParams(textViewParams);
        textView5.setTextColor(Color.WHITE);

        TextView textView6 = new TextView(ctx);
        textView6.setText("Review");
        textView6.setLayoutParams(textViewParams);
        textView6.setTextColor(Color.WHITE);
        editReview.setText(review);
        editReview.setTextColor(Color.WHITE);

        LinearLayout innerLinear = new LinearLayout(ctx);
        innerLinear.setOrientation(LinearLayout.HORIZONTAL);
        innerLinear.setLayoutParams(basicParams);

        //setting the yellow stars in the rating
        for (int i = 0; i < rating; i++) {
            star = new ImageView(ctx);
            star.setImageResource(R.drawable.ic_baseline_star_rate_24);
            star.setColorFilter(Color.parseColor("#ffd000"));
            star.setClickable(true);
            starsArr.add(star);
            innerLinear.addView(star);
        }

        //setting the white stars in the rating
        for (int i = rating; i < 10; i++) {
            star = new ImageView(ctx);
            star.setImageResource(R.drawable.ic_baseline_star_rate_24);
            star.setColorFilter(Color.parseColor("#ffffff"));
            star.setClickable(true);
            starsArr.add(star);
            innerLinear.addView(star);
        }

        TextView textView7 = new TextView(ctx);
        textView7.setText("Status");
        textView7.setLayoutParams(textViewParams);
        textView7.setTextColor(Color.WHITE);
        editFavourite.setText(favourite);
        editFavourite.setTextColor(Color.WHITE);

        //adding the TextViews and the EditTexts to the LinearLayout
        linearLayout.addView(textView1);
        linearLayout.addView(editMovieTitle);

        linearLayout.addView(textView2);
        linearLayout.addView(editYear);

        linearLayout.addView(textView3);
        linearLayout.addView(editDirector);

        linearLayout.addView(textView4);
        linearLayout.addView(editActors);

        linearLayout.addView(textView5);
        linearLayout.addView(innerLinear);

        linearLayout.addView(textView6);
        linearLayout.addView(editReview);

        linearLayout.addView(textView7);
        linearLayout.addView(editFavourite);

        //adding onClickListeners to each of the rating stars
        for (int i = 0; i < starsArr.size(); i++) {
            int currentIteration = i;
            starsArr.get(i).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    for (int i2 = 0; i2 < starsArr.size(); i2++) {
                        iterations = currentIteration;
                        if (i2 <= iterations) {
                            starsArr.get(i2).setColorFilter(Color.parseColor("#ffd000"));
                        } else {
                            starsArr.get(i2).setColorFilter(Color.parseColor("#ffffff"));
                        }
                    }
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        starsArr.clear();
    }

    //updateBtn Button onClick
    public void updateBtn(View view) {

        //checking if any of the fields are null
        if (editMovieTitle.getText().toString().equals("") || editYear.getText().toString().equals("") ||
                editDirector.getText().toString().equals("") || editActors.getText().toString().equals("") ||
                editReview.getText().toString().equals("") || editFavourite.getText().toString().equals("")) {
            Toast.makeText(ctx, "None of the fields can be empty!", Toast.LENGTH_SHORT).show();
        } else {
            //testing whether the year of the movie is greater than 1895 or not
            if (Integer.parseInt(editYear.getText().toString()) <= 1895) {
                Toast.makeText(ctx, "Year should be after 1895", Toast.LENGTH_SHORT).show();
            }
            //checking if the status is equal to "Favourite" or "Not Favourite"
            else if (editFavourite.getText().toString().equals("Favourite") ||
                    editFavourite.getText().toString().equals("Not Favourite")) {

                //updating the favArrList
                if (editFavourite.getText().toString().equals("Favourite")) {
                    for (int i = 0; i < MainActivity.favArrList.size(); i++) {
                        if (MainActivity.favArrList.get(i).equals(originalTitle)) {
                            MainActivity.favArrList.remove(originalTitle);
                            MainActivity.favArrList.add(editMovieTitle.getText().toString());
                        }
                    }
                    MainActivity.favArrList.add(editMovieTitle.getText().toString());
                } else {
                    for (int i = 0; i < MainActivity.favArrList.size(); i++) {
                        if (MainActivity.favArrList.get(i).equals(originalTitle)) {
                            MainActivity.favArrList.remove(originalTitle);
                        }
                    }
                }

                movie_title = editMovieTitle.getText().toString();
                year = Integer.parseInt(editYear.getText().toString());
                director = editDirector.getText().toString();
                actors = editActors.getText().toString();
                rating = iterations + 1;
                review = editReview.getText().toString();
                favourite = editFavourite.getText().toString();

                myDb.setEditMovie();

                Toast.makeText(ctx, "Successfully updated!", Toast.LENGTH_SHORT).show();
            } else {
                //toast indicating that only the strings, "Favourite" or "Not Favourite" would be acceptable statuses
                Toast.makeText(ctx, "Only 'Favourite' or 'Not Favourite' are accepted as the status",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }
}