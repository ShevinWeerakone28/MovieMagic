package com.example.moviemagic;

//imports

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DisplayMovies extends AppCompatActivity {

    //declarations

    MyDatabase myDb;
    Context ctx = this;

    public static ArrayList<String> moviesDisplayed = new ArrayList<String>();
    public static ArrayList<CheckBox> checkedBoxes = new ArrayList<CheckBox>();
    public static CheckBox checkBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_movies);

        LinearLayout linearLayout = findViewById(R.id.linear_display_movies);
        myDb = new MyDatabase(ctx);
        myDb.displayMovies();

        //for loop to create the checkboxes representing the movies currently existing in the database
        for (int i = 0; i < moviesDisplayed.size(); i++) {
            checkBox = new CheckBox(ctx);
            checkBox.setText(moviesDisplayed.get(i));
            checkBox.setChecked(false);
            checkBox.setTextColor(Color.WHITE);
            checkedBoxes.add(checkBox);
            linearLayout.addView(checkBox);

            //checking if favArrList is null or has elements
            if (MainActivity.favArrList.size() > 0) {
                try {
                    //checking the checkbox if the movie is already a favourite
                    for (int i2 = 0; i2 < MainActivity.favArrList.size(); i2++) {
                        if (MainActivity.favArrList.get(i2).equals(moviesDisplayed.get(i))) {
                            checkBox.setChecked(true);
                        }
                    }
                } catch (Exception e) {
                    Logger.getLogger(MyDatabase.class.getName()).log(Level.SEVERE, null, e);
                }
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        moviesDisplayed.clear();
        checkedBoxes.clear();
    }

    //addToFavourites Button onClick
    public void addToFavourites(View view) {
        myDb.addFavourites();
    }
}