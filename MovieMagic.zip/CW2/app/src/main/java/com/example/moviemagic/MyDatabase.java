package com.example.moviemagic;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.logging.Level;
import java.util.logging.Logger;

public class MyDatabase extends SQLiteOpenHelper {

    //declarations

    private static final String DB_NAME = "Movies";
    private static final String DB_TABLE = "movies_watched";
    private static final int DB_VER = 1;

    Context ctx;
    SQLiteDatabase myDb;

    //MyDatabase constructor
    public MyDatabase(Context ctx) {
        super(ctx, DB_NAME, null, DB_VER);
        this.ctx = ctx;
    }

    //creating the columns of MyDatabase
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + DB_TABLE + " (" +
                "_id integer primary key autoincrement," +
                "movie_title text," +
                "year integer," +
                "director text," +
                "actors_actresses text," +
                "rating integer," +
                "review text," +
                "favourite text " +
                ");");
    }

    //onUpgrade of MyDatabase
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + DB_TABLE);
        onCreate(db);
    }

    //registerMovie method to register the movie into MyDatabase
    public void registerMovie(String s1, String s2, String s3, String s4, String s5, String s6) {
        myDb = getWritableDatabase();
        myDb.execSQL("insert into " + DB_TABLE + " (movie_title, year, director, actors_actresses, rating, review, " +
                "favourite) " +
                "values('" + s1 + "', " + Integer.parseInt(s2) + ", '" + s3 + "', '" + s4 + "', " +
                "" + Integer.parseInt(s5) + ", '" + s6 + "', 'Not Favourite');");
        Toast.makeText(ctx, "Movie successfully registered!", Toast.LENGTH_SHORT).show();
    }

    //displayMovies method to display the movie titles of the current movies in MyDatabase
    public void displayMovies() {
        myDb = getReadableDatabase();
        Cursor cursor = myDb.rawQuery("select * from " + DB_TABLE + " order by movie_title;", null);
        StringBuilder stringBuilder = new StringBuilder();

        while (cursor.moveToNext()) {
            String s1 = cursor.getString(1);
            DisplayMovies.moviesDisplayed.add(s1);
            stringBuilder.append(s1 + "\n");
        }
        //Toast.makeText(ctx, stringBuilder, Toast.LENGTH_SHORT).show();
        cursor.close();
    }

    //addFavourites method to retrieve the current movie titles in MyDatabase that would be later represented as checkboxes
    public void addFavourites() {
        myDb = getWritableDatabase();

        //for loop iterating through the checkBoxes array
        for (int i = 0; i < DisplayMovies.checkedBoxes.size(); i++) {
            //checking if the current checkbox is checked or not
            if (DisplayMovies.checkedBoxes.get(i).isChecked()) {
                myDb.execSQL("update " + DB_TABLE + " set favourite = 'Favourite' where movie_title = '" +
                        DisplayMovies.moviesDisplayed.get(i) + "';");

                int repeat = 0;
                for (int i2 = 0; i2 < MainActivity.favArrList.size(); i2++) {
                    if (MainActivity.favArrList.get(i2).equals(DisplayMovies.moviesDisplayed.get(i))) {
                        repeat = 1;
                    }
                }

                //adding the movie title of the checked checkbox to favArrList
                if (repeat == 0) {
                    MainActivity.favArrList.add(DisplayMovies.moviesDisplayed.get(i));
                }
            }
            //if the current checkbox has been left unchecked
            else {
                myDb.execSQL("update " + DB_TABLE + " set favourite = 'Not Favourite' where movie_title = '" +
                        DisplayMovies.moviesDisplayed.get(i) + "';");
                try {
                    for (int i3 = 0; i3 < MainActivity.favArrList.size(); i3++) {
                        //removing the movie title of the unchecked checkbox if it exists in favArrList
                        if (MainActivity.favArrList.get(i3).equals(DisplayMovies.moviesDisplayed.get(i))) {
                            MainActivity.favArrList.remove(i3);
                        }
                    }
                } catch (Exception e) {
                    Logger.getLogger(MyDatabase.class.getName()).log(Level.SEVERE, null, e);
                }
            }
        }

        myDb = getReadableDatabase();
        Cursor cursor = myDb.rawQuery("select * from " + DB_TABLE + " order by movie_title;", null);
        StringBuilder stringBuilder = new StringBuilder();

        while (cursor.moveToNext()) {
            String s1 = cursor.getString(1);
            String s2 = cursor.getString(7);
            //DisplayMovies.moviesDisplayed.add(s1);
            stringBuilder.append(s1 + " - " + s2 + "\n");
        }
        Toast.makeText(ctx, stringBuilder, Toast.LENGTH_SHORT).show();
        cursor.close();
    }

    //getFavsOnStart method to add any new favourites to favArrList
    public void getFavsOnStart() {
        myDb = getReadableDatabase();
        Cursor cursor = myDb.rawQuery("select * from " + DB_TABLE + " where favourite = 'Favourite';",
                null);

        while (cursor.moveToNext()) {
            String s = cursor.getString(1);

            int repeat = 0;
            if (MainActivity.favArrList.size() > 0) {
                for (int i = 0; i < MainActivity.favArrList.size(); i++) {
                    if (MainActivity.favArrList.get(i).equals(s)) {
                        repeat = 1;
                    }
                }
            }
            if (repeat == 0) {
                MainActivity.favArrList.add(s);
            }
        }
        cursor.close();
    }

    //favourites method to update whether or not any of the favourite movies have been unchecked to no longer being a favourite
    public void favourites() {
        myDb = getWritableDatabase();

        //for loop iterating through the favStillChecked ArrayList
        for (int i = 0; i < Favourites.favStillChecked.size(); i++) {
            //if the movie title checkbox has been unchecked, it will be updated as a "Not Favourite"
            if (!Favourites.favStillChecked.get(i).isChecked()) {

                myDb.execSQL("update " + DB_TABLE + " set favourite = 'Not Favourite' where movie_title = '" +
                        Favourites.favMovies.get(i) + "';");
                try {
                    for (int i2 = 0; i2 < MainActivity.favArrList.size(); i2++) {
                        //removing the unchecked movie title from favArrList
                        if (MainActivity.favArrList.get(i2).equals(Favourites.favMovies.get(i))) {
                            MainActivity.favArrList.remove(i2);
                        }
                    }
                } catch (Exception e) {
                    Logger.getLogger(MyDatabase.class.getName()).log(Level.SEVERE, null, e);
                }
            }
        }
    }

    //editMovies method to display a list of all the possible movie titles in the database, available for editing
    public void editMovies() {
        myDb = getReadableDatabase();
        Cursor cursor = myDb.rawQuery("select * from " + DB_TABLE + " order by movie_title;", null);

        while (cursor.moveToNext()) {
            String s = cursor.getString(1);
            EditMovies.editMovieTitles.add(s);
        }
        cursor.close();
    }

    //editMovie method to display all the information on the chosen movie from MyDatabase to be edited
    public void getEditMovie() {
        myDb = getReadableDatabase();
        Cursor cursor = myDb.rawQuery("select * from " + DB_TABLE + " where movie_title = '" +
                EditMovies.editMovieTitles.get(EditMovies.position) + "';", null);

        while (cursor.moveToNext()) {
            EditMovie.movie_title = cursor.getString(1);
            EditMovie.year = cursor.getInt(2);
            EditMovie.director = cursor.getString(3);
            EditMovie.actors = cursor.getString(4);
            EditMovie.rating = cursor.getInt(5);
            EditMovie.review = cursor.getString(6);
            EditMovie.favourite = cursor.getString(7);
        }
        cursor.close();
    }

    //setEditMovie method to update the details on the movie in MyDatabase that had been edited
    public void setEditMovie() {
        myDb = getWritableDatabase();

        myDb.execSQL("update " + DB_TABLE + " set movie_title = '" + EditMovie.movie_title + "', " +
                "year = " + EditMovie.year + ", " +
                "director = '" + EditMovie.director + "', " +
                "actors_actresses = '" + EditMovie.actors + "', " +
                "rating = " + EditMovie.rating + ", " +
                "review = '" + EditMovie.review + "', " +
                "favourite = '" + EditMovie.favourite + "' " +
                "where movie_title = '" + EditMovies.movieToBeEdited + "';");
    }

    //search method to search for a particular String that may lie within the movie_title, director or actor fields of
    //MyDatabase
    public void search() {
        myDb = getReadableDatabase();
        Cursor cursor = myDb.rawQuery("select * from " + DB_TABLE + " where " +
                "movie_title like '%" + Search.lookupEntered + "%' or " +
                "director like '%" + Search.lookupEntered + "%' or " +
                "actors_actresses like '%" + Search.lookupEntered + "%';", null);

        while (cursor.moveToNext()) {
            Search.searchMovieTitles.add(cursor.getString(1));
            Search.searchYears.add(cursor.getInt(2));
            Search.searchDirectors.add(cursor.getString(3));
            Search.searchActors.add(cursor.getString(4));
            Search.searchRatings.add(cursor.getInt(5));
            Search.searchReviews.add(cursor.getString(6));
            Search.searchFavourites.add(cursor.getString(7));
        }
        cursor.close();
    }

    //displayMoviesInDb method to obtain a list of all the existing movie titles in MyDatabase
    public void displayMoviesInDb() {
        myDb = getReadableDatabase();
        Cursor cursor = myDb.rawQuery("select * from " + DB_TABLE + ";", null);

        while (cursor.moveToNext()) {
            Ratings.moviesExistingInDb.add(cursor.getString(1));
        }
    }
}
