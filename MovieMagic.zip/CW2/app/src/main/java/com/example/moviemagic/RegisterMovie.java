package com.example.moviemagic;

//imports

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterMovie extends AppCompatActivity {

    //declarations

    private static EditText title;
    private static EditText year;
    private static EditText director;
    private static EditText actor;
    private static EditText rating;
    private static EditText review;

    MyDatabase myDb;
    Context ctx = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_movie);

        myDb = new MyDatabase(ctx);
    }

    //saveMovie Button onClick
    public void saveMovie(View view) {

        //creating EditTexts from the XML
        title = findViewById(R.id.title_edit_text);
        year = findViewById(R.id.year_edit_text);
        director = findViewById(R.id.director_edit_text);
        actor = findViewById(R.id.actor_edit_text);
        rating = findViewById(R.id.rating_edit_text);
        review = findViewById(R.id.review_edit_text);

        //checking if any of the EditTexts have a null value
        if (title.getText().toString().equals("") || year.getText().toString().equals("") ||
                director.getText().toString().equals("") || actor.getText().toString().equals("") ||
                rating.getText().toString().equals("") || review.getText().toString().equals("")) {
            Toast.makeText(ctx, "None of the fields can be empty!", Toast.LENGTH_SHORT).show();
        } else {
            //checking if the year of the movie is greater than 1895 or not
            if (Integer.parseInt(year.getText().toString()) <= 1895) {
                Toast.makeText(ctx, "Year should be after 1895", Toast.LENGTH_SHORT).show();
            }
            //checking if the rating is between the range, inclusive, of 1 and 10
            else if (Integer.parseInt(rating.getText().toString()) < 1 ||
                    Integer.parseInt(rating.getText().toString()) > 10) {
                Toast.makeText(ctx, "Rating should be between 1 and 10", Toast.LENGTH_SHORT).show();
            }
            //making call to registerMovie in MyDatabase class
            else {
                myDb.registerMovie(title.getText().toString(), year.getText().toString(), director.getText().toString(),
                        actor.getText().toString(), rating.getText().toString(), review.getText().toString());
            }
        }
    }
}