package com.example.moviemagic;

//imports

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Favourites extends AppCompatActivity {

    //declarations

    MyDatabase myDb;
    Context ctx = this;

    public static ArrayList<String> favMovies = new ArrayList<String>();
    public static ArrayList<CheckBox> favStillChecked = new ArrayList<CheckBox>();
    public static CheckBox checkBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourites);

        LinearLayout linearLayout = findViewById(R.id.linear_favourites);
        myDb = new MyDatabase(ctx);

        //creating checked checkboxes of the movies that are already favourites
        for (int i = 0; i < MainActivity.favArrList.size(); i++) {
            checkBox = new CheckBox(ctx);
            checkBox.setText(MainActivity.favArrList.get(i));
            checkBox.setTextColor(Color.WHITE);
            checkBox.setChecked(true);
            favStillChecked.add(checkBox);
            favMovies.add(MainActivity.favArrList.get(i));
            linearLayout.addView(checkBox);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        favMovies.clear();
        favStillChecked.clear();
    }

    //saveFavourites Button onClick
    public void saveFavourites(View view) {
        myDb.favourites();
        Toast.makeText(ctx, "Successfully saved!", Toast.LENGTH_SHORT).show();
    }
}