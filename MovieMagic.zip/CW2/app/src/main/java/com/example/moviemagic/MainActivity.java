package com.example.moviemagic;

//imports

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //declarations

    public static ArrayList<String> favArrList = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MyDatabase myDb = new MyDatabase(this);
        myDb.getFavsOnStart();
        //Toast.makeText(this, favArrList.toString(), Toast.LENGTH_LONG).show();
    }

    //call to RegisterMovie Activity
    public void registerMovie(View view) {
        startActivity(new Intent(MainActivity.this, RegisterMovie.class));
    }

    //call to DisplayMovies Activity
    public void displayMovies(View view) {
        startActivity(new Intent(MainActivity.this, DisplayMovies.class));
    }

    //call to Favourites Activity
    public void favourites(View view) {
        startActivity(new Intent(MainActivity.this, Favourites.class));
    }

    //call to EditMovies Activity
    public void editMovies(View view) {
        startActivity(new Intent(MainActivity.this, EditMovies.class));
    }

    //call to Search Activity
    public void search(View view) {
        startActivity(new Intent(MainActivity.this, Search.class));
    }

    //call to Ratings Activity
    public void ratings(View view) {
        startActivity(new Intent(MainActivity.this, Ratings.class));
    }
}